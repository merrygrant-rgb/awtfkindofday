# 🚀 DEPLOY YOUR CMS - STEP BY STEP

## What You Just Downloaded

The file `wtf-kind-of-day-cms.tar.gz` contains your complete publishing platform.

---

## 📥 STEP 1: Extract the Files (2 minutes)

### On Windows:
1. Download the `.tar.gz` file above
2. Right-click the file
3. Choose "Extract All" (if you have 7-Zip or WinRAR installed)
   - Don't have it? Download 7-Zip free: https://www.7-zip.org
4. Extract to your Desktop
5. You'll get a folder called `wtf-kind-of-day-cms`

### On Mac:
1. Download the `.tar.gz` file
2. Double-click it - it extracts automatically
3. You'll get a folder called `wtf-kind-of-day-cms`

---

## 🐙 STEP 2: Create GitHub Account (3 minutes)

### If You Don't Have GitHub:

1. Go to: **https://github.com**
2. Click **"Sign up"**
3. Enter:
   - **Email**: Your email
   - **Password**: Create a password
   - **Username**: Pick anything (like `yourname-wtf`)
4. Verify your email
5. ✅ Done!

### If You Already Have GitHub:
Just log in!

---

## 📤 STEP 3: Upload to GitHub (5 minutes)

### Create Repository:

1. **Log into GitHub**
2. Click the **"+"** button (top right)
3. Click **"New repository"**
4. Fill in:
   ```
   Repository name: wtf-kind-of-day
   Description: My humor blog with CMS
   Public: ✓ (MUST be public for free Netlify)
   Add a README: ✓ (check this box)
   ```
5. Click **"Create repository"**

### Upload Your Files:

1. You're now on your repository page
2. Click **"uploading an existing file"** (blue link in the middle)
3. Open the `wtf-kind-of-day-cms` folder you extracted
4. **Select ALL files and folders inside it**
   - Don't upload the folder itself, upload what's INSIDE
5. Drag them all to GitHub's upload area
6. Scroll down
7. Type commit message: "Initial CMS setup"
8. Click **"Commit changes"**
9. Wait 1-2 minutes while files upload
10. ✅ Files are on GitHub!

---

## 🌐 STEP 4: Deploy to Netlify (5 minutes)

### Create Netlify Account:

1. Go to: **https://app.netlify.com**
2. Click **"Sign up"**
3. Choose **"Sign up with GitHub"** ← IMPORTANT
4. Authorize Netlify
5. ✅ Connected!

### Deploy Your Site:

1. In Netlify dashboard, click **"Add new site"**
2. Click **"Import an existing project"**
3. Click **"Deploy with GitHub"**
4. Find your repository: **wtf-kind-of-day**
5. Click on it
6. **Build settings:**
   ```
   Build command: npm run build
   Publish directory: _site
   ```
7. Click **"Deploy site"**
8. **Wait 3-5 minutes** (first build takes longer)
9. Watch the deploy log - you'll see it installing and building
10. ✅ When it says "Published", you're live!

---

## 🎉 STEP 5: Get Your URL

After deploy finishes:

1. Netlify gives you a URL like:
   ```
   https://sparkly-cupcake-123456.netlify.app
   ```
2. **Click it** to see your site!
3. You should see a basic page saying "Your site is being built!"

---

## 🔐 STEP 6: Enable the CMS (5 minutes)

### Turn On Identity:

1. In your Netlify dashboard, click **"Identity"** (left sidebar)
2. Click **"Enable Identity"**
3. Done!

### Turn On Git Gateway:

1. Still in **Identity** tab
2. Scroll to **"Services"** section
3. Click **"Enable Git Gateway"**
4. Done!

### Invite Yourself:

1. Still in **Identity** tab
2. Click **"Invite users"**
3. Enter **your email**
4. Check your email
5. Click the **invite link**
6. **Set your password**
7. ✅ You're in!

---

## ✍️ STEP 7: Write Your First Post! (5 minutes)

### Access Admin Panel:

1. Go to: `https://your-site-url.netlify.app/admin`
2. **Log in** with your email/password
3. You're in the CMS!

### Create a Post:

1. Click **"Blog Posts"** (left sidebar)
2. Click **"New Blog Posts"**
3. Fill in:
   - **Title**: "My First WTF Moment"
   - **Date**: Pick today
   - **Category**: Choose "Work WTFs" (or any category)
   - **Featured Post**: Check if you want it on homepage
   - **Teaser**: "A short description of this post"
   - **Body**: Write your post!
   - **Read Time**: 5
4. Click **"Publish"** (top right)
5. Wait 2-3 minutes for Netlify to rebuild
6. **Refresh your site**
7. ✅ Your post is live!

---

## 🎨 STEP 8: Customize Settings (Optional)

### Change Homepage Text:

1. In `/admin`, click **"Site Settings"**
2. Click **"Homepage"**
3. Edit:
   - Hero headline
   - Subhead
   - CTA button text
   - Stats
4. Click **"Publish"**
5. ✅ Homepage updates!

---

## 🔗 STEP 9: Connect Your Domain (Optional)

### If You Have wtfcrimetalk.com:

1. In Netlify, click **"Domain management"**
2. Click **"Add custom domain"**
3. Enter: `wtfcrimetalk.com`
4. Click **"Verify"**
5. Netlify shows you **DNS instructions**
6. Go to **GoDaddy** (or wherever your domain is)
7. Update your DNS as instructed
8. Wait 24-48 hours
9. ✅ Your site is at your custom domain!

---

## ✅ SUCCESS CHECKLIST

After following all steps:

- [ ] Downloaded and extracted files
- [ ] Created GitHub account
- [ ] Uploaded files to GitHub repository
- [ ] Created Netlify account
- [ ] Connected GitHub to Netlify
- [ ] Site deployed successfully
- [ ] Enabled Identity in Netlify
- [ ] Enabled Git Gateway
- [ ] Invited yourself via email
- [ ] Logged into `/admin` panel
- [ ] Created first blog post
- [ ] Post shows on website

**All checked?** You're done! 🎉

---

## 🆘 TROUBLESHOOTING

### "Build failed" in Netlify
**What to check:**
- Build command is: `npm run build`
- Publish directory is: `_site`
- All files uploaded correctly to GitHub

**How to fix:**
1. Go to Deploys tab
2. Click failed deploy
3. Read error message
4. Usually it's a typo - fix in GitHub and redeploy

### "Can't log into /admin"
**Fix:**
- Make sure Identity is enabled in Netlify
- Make sure you accepted the email invite
- Try password reset if needed

### "Site shows 404"
**Fix:**
- Make sure build completed successfully
- Check Deploys tab shows "Published"
- Clear browser cache (Ctrl+Shift+R)

### "Post not showing"
**Fix:**
- Wait 2-3 minutes after clicking Publish
- Check Deploys tab - new deploy should be running
- Make sure post is Published, not Draft

---

## 📞 NEED MORE HELP?

**Open the guides in your downloaded folder:**
- `COMPLETE_BEGINNERS_GUIDE.md` - Full detailed guide
- `README.md` - Technical overview

**Online Resources:**
- Netlify Docs: https://docs.netlify.com
- Decap CMS Docs: https://decapcms.org/docs
- GitHub Help: https://docs.github.com

---

## 🎯 YOUR WORKFLOW AFTER SETUP

**Every time you want to post:**

1. Go to `yoursite.com/admin`
2. Log in
3. Click "New Blog Posts"
4. Write post
5. Click "Publish"
6. Wait 2 minutes
7. ✅ Live!

**To add merch:**

1. Go to `/admin`
2. Click "Merchandise"
3. Click "New Merchandise"
4. Fill in details
5. Upload images
6. Click "Publish"
7. ✅ Product appears!

---

## 💰 COSTS

- **GitHub**: FREE
- **Netlify**: FREE (100GB bandwidth/month)
- **Domain**: ~$15/year (if you use custom domain)
- **Total**: Basically FREE!

---

## ⏱️ TIME INVESTMENT

- **One-time setup**: 30 minutes
- **Writing each post**: 5-10 minutes
- **Adding each product**: 3-5 minutes
- **Monthly maintenance**: 0 minutes (automatic!)

---

## 🎉 YOU'RE READY!

Follow the steps above, and you'll have a complete publishing platform where you NEVER have to edit HTML again!

Everything is done through the admin panel at `/admin`.

**Start with STEP 1 and work through the checklist!**

Good luck! 🚀
